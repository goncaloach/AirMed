import os
import django.contrib.auth

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User, Group
from django.http import HttpResponse, HttpResponseRedirect
from django.utils import timezone

from .models import Cliente, Medico, Agendamento
from django.shortcuts import get_object_or_404, render
from django.urls import reverse, reverse_lazy
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.decorators import login_required, user_passes_test, permission_required
from django.contrib.auth.models import Permission
from django.contrib import messages
from datetime import datetime
from datetime import timedelta
import smtplib
import random


# TODO edit profile pic
# TODO permissoes


def loadDefaultContext(request):
    fs = FileSystemStorage()
    isMedic = None
    isClient = None
    if request.user.is_superuser:
        uploaded_file_url = fs.url("profile_picture.png")
    else:
        uploaded_file_url = fs.url(request.user.username + ".png")
        isMedic = request.user.groups.filter(name="Medic").exists()
        isClient = request.user.groups.filter(name="Client").exists()
    context = {'uploaded_file_url': uploaded_file_url,
               'isMedic': isMedic,
               'isClient': isClient}
    return context


def check_superuser(user):
    return user.is_superuser


def check_medic(user):
    return user.groups.filter(name='Medic').exists()


def check_client(user):
    return user.groups.filter(name='Client').exists()


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        if not username or not password:
            messages.error(request, 'Fields cannot be left blank')
            return HttpResponseRedirect(reverse('marcarExame:login_view', args=()))
        user = authenticate(username=username, password=password)
        if user is None:
            messages.error(request, 'Invalid Credentials')
            return HttpResponseRedirect(reverse('marcarExame:login_view', args=()))
        login(request, user)
        return HttpResponseRedirect(reverse('marcarExame:dash', args=()))
    return render(request, 'marcarExame/login.html')


@login_required
def logout_user(request):
    logout(request)
    return HttpResponseRedirect(reverse('marcarExame:login_view'))


@login_required
def dash(request):
    return render(request, 'marcarExame/dash.html', loadDefaultContext(request))


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        birth_date = request.POST['birth_date']
        phone = request.POST['phone']
        address = request.POST['address']
        nhs = request.POST['nhs']
        if not username or not password or not email or not first_name or not birth_date or not 'img' in request.FILES \
                or not phone or not address or not nhs or not last_name:
            messages.error(request, 'Fields cannot be left blank')
            return HttpResponseRedirect(reverse('marcarExame:register', args=()))
        if len(username) > 50 or len(password) > 50 or len(email) > 50 or len(first_name) > 50 or len(
                last_name) > 50 or len(phone) != 9 or len(nhs) != 9 or len(address) > 100 \
                or not phone.isnumeric() or not nhs.isnumeric():
            messages.error(request, 'Invalid field input(s)')
            return HttpResponseRedirect(reverse('marcarExame:register', args=()))
        birthDate = datetime.strptime(birth_date, '%Y-%m-%d').date()
        if (datetime.now().date() - birthDate) < timedelta(days=365 * 18):
            messages.error(request, 'You must be at least 18 years old to create an account')
            return HttpResponseRedirect(reverse('marcarExame:register', args=()))
        fs = FileSystemStorage()
        uploaded_file = request.FILES['img']
        fileName, extension = os.path.splitext(uploaded_file.name)
        lowerExtension = extension.lower()
        if not (lowerExtension == '.jpeg' or lowerExtension == '.png' or lowerExtension == '.gif' or lowerExtension == '.jpg'):
            messages.error(request, 'You must choose an image file')
            return HttpResponseRedirect(reverse('marcarExame:register', args=()))
        try:
            User.objects.get(username=username)
            messages.error(request, 'This username already exists, please choose a different one')
            return HttpResponseRedirect(reverse('marcarExame:register', args=()))
        except:
            user = User.objects.create_user(username, email, password, first_name=first_name, last_name=last_name)
            Cliente(user=user, dataNascimento=birth_date, telefone=phone, morada=address, numUtente=nhs).save()
            group = Group.objects.get(name="Client")
            group.user_set.add(user)
            fs.save(username + 'png', request.FILES['img'])
            messages.success(request, 'Client created successfully')
            login(request, authenticate(username=username, password=password))
            return HttpResponseRedirect(reverse('marcarExame:dash', args=()))
    else:
        return render(request, 'marcarExame/register.html')


@login_required
def about(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        newPassword = request.POST['password']
        oldPassword = request.POST['current_password']
        if not first_name or not last_name or not email:
            messages.error(request, 'Fields cannot be left blank')
            return HttpResponseRedirect(reverse('marcarExame:about', args=()))
        if len(email) > 50 or len(first_name) > 50 or len(last_name) > 50:
            messages.error(request, 'Invalid field input(s)')
            return HttpResponseRedirect(reverse('marcarExame:about', args=()))
        user = User.objects.get(username=request.user.username)
        user.first_name = first_name
        user.last_name = last_name
        user.email = email
        if newPassword and oldPassword:
            if authenticate(username=request.user.username, password=oldPassword):
                user.set_password(newPassword)
                login(request, user)
            else:
                messages.error(request, 'Invalid Current password')
                return HttpResponseRedirect(reverse('marcarExame:about', args=()))
        user.save()
        if not request.user.is_superuser:
            phone = request.POST['phone']
            address = request.POST['address']
            if not phone or not address:
                messages.error(request, 'Fields cannot be left blank')
                return HttpResponseRedirect(reverse('marcarExame:about', args=()))
            if len(phone) != 9 or len(address) > 100 or not phone.isnumeric():
                messages.error(request, 'Invalid field input(s)')
                return HttpResponseRedirect(reverse('marcarExame:about', args=()))
            if request.user.groups.filter(name="Medic").exists():
                medic = User.objects.get(username=request.user.username).medico
                medic.telefone = phone
                medic.morada = address
                medic.save()
            elif request.user.groups.filter(name="Client").exists():
                client = User.objects.get(username=request.user.username).cliente
                client.telefone = phone
                client.morada = address
                client.save()
        messages.success(request, 'Fields updated successfully')
        return HttpResponseRedirect(reverse('marcarExame:about', args=()))

    fs = FileSystemStorage()
    context = {}
    if request.user.is_superuser:
        context["uploaded_file_url"] = fs.url("profile_picture.png")
    else:
        context["uploaded_file_url"] = fs.url(request.user.username + ".png")
        isMedic = request.user.groups.filter(name="Medic").exists()
        isClient = request.user.groups.filter(name="Client").exists()
        context["isMedic"] = isMedic
        context["isClient"] = isClient
        if isMedic:
            medic = User.objects.get(username=request.user.username).medico
            context["clinic"] = medic.clinica
            context["medicNum"] = medic.numMedico
            context["birth_date"] = medic.dataNascimento
            context["phone"] = medic.telefone
            context["address"] = medic.morada
            context["district"] = medic.distrito
        else:
            client = User.objects.get(username=request.user.username).cliente
            context["nhs"] = client.numUtente
            context["birth_date"] = client.dataNascimento
            context["phone"] = client.telefone
            context["address"] = client.morada
    return render(request, 'marcarExame/about.html', context)


@login_required
@user_passes_test(check_superuser, login_url=reverse_lazy('marcarExame:login_view'))
def registerMedic(request):
    if request.method == 'POST':
        username = request.POST['username']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        birth_date = request.POST['birth_date']
        phone = request.POST['phone']
        address = request.POST['address']
        medicNumber = request.POST['medicNum']
        clinic = request.POST['clinic']
        district = request.POST['district']
        if not username or not email or not first_name or not last_name or not birth_date or not address \
                or not 'img' in request.FILES or not phone or not medicNumber or not clinic or not district:
            messages.error(request, 'Fields cannot be left blank')
            return HttpResponseRedirect(reverse('marcarExame:registerMedic', args=()))
        if len(username) > 50 or len(email) > 50 or len(first_name) > 50 or len(last_name) > 50 \
                or len(phone) != 9 or len(medicNumber) != 9 or len(address) > 100 \
                or not phone.isnumeric() or not medicNumber.isnumeric():
            messages.error(request, 'Invalid field input(s)')
            return HttpResponseRedirect(reverse('marcarExame:registerMedic', args=()))
        birthDate = datetime.strptime(birth_date, '%Y-%m-%d').date()
        if (datetime.now().date() - birthDate) < timedelta(days=365 * 18):
            messages.error(request, 'The medic must be at least 18 years old')
            return HttpResponseRedirect(reverse('marcarExame:registerMedic', args=()))
        fs = FileSystemStorage()
        uploaded_file = request.FILES['img']
        fileName, extension = os.path.splitext(uploaded_file.name)
        lowerExtension = extension.lower()
        if not (lowerExtension == '.jpeg' or lowerExtension == '.png' or lowerExtension == '.gif' or lowerExtension == '.jpg'):
            messages.error(request, 'You must choose an image file')
            return HttpResponseRedirect(reverse('marcarExame:registerMedic', args=()))
        try:
            User.objects.get(username=username)
            messages.error(request, 'This username already exists, please choose a different one')
            return HttpResponseRedirect(reverse('marcarExame:registerMedic', args=()))
        except:
            psw = ''.join(random.choice('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.@_&%') for i in range(16))
            user = User.objects.create_user(username, email, psw, first_name=first_name, last_name=last_name)
            Medico(user=user, dataNascimento=birth_date, telefone=phone, morada=address, numMedico=medicNumber,
                clinica=clinic, distrito=district).save()
            sendPswEmail(user.username, user.email, psw)
            group = Group.objects.get(name="Medic")
            group.user_set.add(user)
            fs.save(username + ".png", request.FILES['img'])
            messages.success(request, 'Medic created successfully')
            return HttpResponseRedirect(reverse('marcarExame:dash', args=()))
    return render(request, 'marcarExame/registerMedic.html', loadDefaultContext(request))


# TODO add permissions
@login_required
def createAppointments(request):
    if request.method == 'POST':
        dataAp = request.POST['dataAp']
        examType = request.POST['exam_type']
        slotTime = request.POST['slot_time']

        date_format_str = '%d/%m/%Y %H:%M'

        if examType != "X-Ray" and examType != "MRI" and examType != "CAT" and examType != "ECO":
            messages.error(request, 'Exam Type can only be: X-Ray,MRI,CAT or ECO!')
            return HttpResponseRedirect(reverse('marcarExame:createAppointments', args=()))
            
        if not dataAp or not examType:
            messages.error(request, 'Please fill all fields')
            return HttpResponseRedirect(reverse('marcarExame:createAppointments', args=()))
        else:
            given_time = datetime.strptime(dataAp, date_format_str)
            final_time = given_time + timedelta(minutes=int(slotTime))

            Agendamento(idMedico=User.objects.get(username=request.user.username).medico, dataHoraInicio=given_time,
                        dataHoraFim=final_time, tipoExame=examType).save()
            messages.success(request, 'Appointment created successfully')
            return HttpResponseRedirect(reverse('marcarExame:createAppointments', args=()))
    else:
        return render(request, 'marcarExame/createAppointments.html', loadDefaultContext(request))


@login_required
def pastAppointments(request):
    if request.method == 'POST':
        startDate = request.POST['start_date']
        endDate = request.POST['end_date']
        examType = request.POST['exam_type']
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isMedic = request.user.groups.filter(name="Medic").exists()
            context["isMedic"] = isMedic
            if isMedic:
                today = datetime.now()
                appointments_list = Agendamento.objects.filter(
                    idMedico=User.objects.get(username=request.user.username).medico.id, idCliente__isnull=False,
                    tipoExame=examType, dataHoraInicio__range=[startDate, endDate], dataHoraInicio__lte=today)
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/pastAppointments.html', context)
    else:

        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isMedic = request.user.groups.filter(name="Medic").exists()
            context["isMedic"] = isMedic
            if isMedic:
                today = datetime.now()
                appointments_list = Agendamento.objects.filter(
                    idMedico=User.objects.get(username=request.user.username).medico.id, dataHoraFim__lte=today,
                    idCliente__isnull=False)
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/pastAppointments.html', context)


@login_required
def futureAppointments(request):
    if request.method == 'POST':
        startDate = request.POST['start_date']
        endDate = request.POST['end_date']
        examType = request.POST['exam_type']
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isMedic = request.user.groups.filter(name="Medic").exists()
            context["isMedic"] = isMedic
            if isMedic:
                today = datetime.now()
                appointments_list = Agendamento.objects.filter(
                    idMedico=User.objects.get(username=request.user.username).medico.id, estado=False,
                    idCliente__isnull=False, tipoExame=examType, dataHoraInicio__range=[startDate, endDate],
                    dataHoraInicio__gte=today)
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/futureAppointments.html', context)
    else:
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isMedic = request.user.groups.filter(name="Medic").exists()
            context["isMedic"] = isMedic
            if isMedic:
                today = datetime.now()
                appointments_list = Agendamento.objects.filter(
                    idMedico=User.objects.get(username=request.user.username).medico.id, idCliente__isnull=False,
                    estado=False, dataHoraFim__gte=today)
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/futureAppointments.html', context)


@login_required
def myAvailability(request):
    if request.method == 'POST':
        startDate = request.POST['start_date']
        endDate = request.POST['end_date']
        examType = request.POST['exam_type']
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isMedic = request.user.groups.filter(name="Medic").exists()
            context["isMedic"] = isMedic
            if isMedic:
                today = datetime.now()
                appointments_list = Agendamento.objects.filter(
                    idMedico=User.objects.get(username=request.user.username).medico.id, estado=False, idCliente=None,
                    tipoExame=examType, dataHoraInicio__range=[startDate, endDate], dataHoraInicio__gte=today)
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/myAvailability.html', context)
    else:
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isMedic = request.user.groups.filter(name="Medic").exists()
            context["isMedic"] = isMedic
            if isMedic:
                today = datetime.now()
                appointments_list = Agendamento.objects.filter(
                    idMedico=User.objects.get(username=request.user.username).medico.id, estado=False, idCliente=None,
                    dataHoraInicio__gte=today)
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/myAvailability.html', context)


@login_required
def myAppointments(request):
    if request.method == 'POST':
        startDate = request.POST['start_date']
        endDate = request.POST['end_date']
        examType = request.POST['exam_type']
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isClient = request.user.groups.filter(name="Client").exists()
            context["isClient"] = isClient
            if isClient:
                appointments_list = Agendamento.objects.filter(idCliente=Cliente.objects.get(user=request.user),
                                                               tipoExame=examType,
                                                               dataHoraInicio__range=[startDate, endDate]).order_by('-estado')
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/myAppointments.html', context)
    else:
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isClient = request.user.groups.filter(name="Client").exists()
            context["isClient"] = isClient
            if isClient:
                appointments_list = Agendamento.objects.filter(idCliente=Cliente.objects.get(user=request.user)).order_by('-estado')
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/myAppointments.html', context)


@login_required
def scheduleAppointments(request):
    if request.method == 'POST':
        startDate = request.POST['start_date']
        endDate = request.POST['end_date']
        examType = request.POST['exam_type']
        district = request.POST['district']
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            today = datetime.now()
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            appointments_list_medic = Agendamento.objects.filter(tipoExame=examType, idCliente__isnull=True,
                                                                 dataHoraInicio__range=[startDate, endDate],
                                                                 dataHoraInicio__gte=today).values('idMedico')
            medic_list = Medico.objects.filter(id__in=appointments_list_medic, distrito=district)
            appointments_list = Agendamento.objects.filter(idCliente__isnull=True, tipoExame=examType,
                                                           dataHoraInicio__range=[startDate, endDate],
                                                           dataHoraInicio__gte=today)
            context["appointments_list"] = appointments_list
            context["medic_list"] = medic_list
            isClient = request.user.groups.filter(name="Client").exists()
            context["isClient"] = isClient
        return render(request, 'marcarExame/filteredAppointments.html', context)
    else:
        return render(request, 'marcarExame/scheduleAppointments.html', loadDefaultContext(request))


@login_required
# @user_passes_test(is_medic, login_url=reverse_lazy('marcarExame:pastAppointments'))
def addResult(request, appointment_id):
    if request.method == 'POST':
        resultado = request.FILES['result']
        fs = FileSystemStorage()
        context = {}
        if request.user.is_superuser:
            context["uploaded_file_url"] = fs.url("profile_picture.png")
        else:
            context["uploaded_file_url"] = fs.url(request.user.username + ".png")
            isMedic = request.user.groups.filter(name="Medic").exists()
            context["isMedic"] = isMedic
            if isMedic:
                fs = FileSystemStorage()
                fs.save("appointment" + str(appointment_id) + ".zip", resultado)
                appointment = get_object_or_404(Agendamento, pk=appointment_id)
                appointment.estado = True
                appointment.save()
                today = datetime.now()
                appointments_list = Agendamento.objects.filter(
                    idMedico=User.objects.get(username=request.user.username).medico.id, dataHoraFim__lte=today,
                    idCliente__isnull=False)
                context["appointments_list"] = appointments_list
        return render(request, 'marcarExame/pastAppointments.html', context)


@login_required
# @user_passes_test(is_medic, login_url=reverse_lazy('marcarExame:pastAppointments'))
def removeAppointment(request, appointment_id):
    fs = FileSystemStorage()
    context = {}
    if request.user.is_superuser:
        context["uploaded_file_url"] = fs.url("profile_picture.png")
    else:
        context["uploaded_file_url"] = fs.url(request.user.username + ".png")
        isMedic = request.user.groups.filter(name="Medic").exists()
        context["isMedic"] = isMedic
        if isMedic:
            appointment = get_object_or_404(Agendamento, pk=appointment_id)
            appointment.delete()
            today = datetime.now()
            appointments_list = Agendamento.objects.filter(
                idMedico=User.objects.get(username=request.user.username).medico.id, dataHoraInicio__lte=today)
            context["appointments_list"] = appointments_list
    return render(request, 'marcarExame/dash.html', context)


@login_required
# @user_passes_test(is_medic, login_url=reverse_lazy('marcarExame:pastAppointments'))
def joinAppointment(request, appointment_id):
    fs = FileSystemStorage()
    context = {}
    if request.user.is_superuser:
        context["uploaded_file_url"] = fs.url("profile_picture.png")
    else:
        context["uploaded_file_url"] = fs.url(request.user.username + ".png")
        isClient = request.user.groups.filter(name="Client").exists()
        context["isClient"] = isClient
        if isClient:
            appointment = get_object_or_404(Agendamento, pk=appointment_id)
            appointment.idCliente = Cliente.objects.get(user=request.user)
            appointment.save()
            sendConfirmationEmail(request.user.email, appointment)
            appointments_list = Agendamento.objects.filter(idCliente=Cliente.objects.get(user=request.user))
            context["appointments_list"] = appointments_list
    return render(request, 'marcarExame/myAppointments.html', context)


def sendConfirmationEmail(email, appointment):
    server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    server.login("airmed2022@gmail.com", "rXN$8683rx7sj(n{")
    details = "\nThe appointment of a " + str(appointment.tipoExame) + " on " + str(
        appointment.dataHoraInicio) + " with doctor " + str(appointment.idMedico) + " is confirmed!"
    print(details)
    server.sendmail("airmed2022@gmail.com", str(email), str(details))
    server.quit()


def sendPswEmail(username, email, psw):
    server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    server.login("airmed2022@gmail.com", "rXN$8683rx7sj(n{")
    details = "\nHello " + str(username) + " thank you for joining AirMed! Your password is " + str(
        psw) + " change it as soon as possible! Please rate our service at https://forms.gle/iwURKHyyYw9dhWfBA ."
    print(details)
    server.sendmail("airmed2022@gmail.com", str(email), str(details))
    server.quit()
